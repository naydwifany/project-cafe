package dao;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import javax.swing.JOptionPane;
import java.sql.*;
/**
 *
 * @author nayla
 */
public class DbOperations {
    public static void setDataorDelete(String Query,String msg){
        try{
            Connection con = ConnectionProvider.getCon();
            Statement st = con.createStatement();
            st.executeUpdate(Query);
            if(!msg.equals(""))
                JOptionPane.showMessageDialog(null, msg);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e , "Message", JOptionPane. ERROR_MESSAGE);
        }
    }
    
    public static ResultSet getData(String query) {
        try{
            Connection con = ConnectionProvider.getCon();
            Statement st = con.createStatement ();
            ResultSet rs = st.executeQuery(query);
            return rs;
        }
        catch(Exception e){
            JoptionPane.showMessageDialog(null, e, "Message", JOptionPane.ERROR_MESSAGE);
            return null;
        }     
    }

    static void setDataOrDelete(String userTable, String user_Table_Created_Successfully) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void setDataOrDelete(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private static class JoptionPane {

        private static void showMessageDialog(Object object, Exception e, String message, int ERROR_MESSAGE) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public JoptionPane() {
        }
    }
}
